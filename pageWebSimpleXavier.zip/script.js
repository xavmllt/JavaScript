let bouton = document.querySelector("input");

bouton.addEventListener("click", () =>{
    alert("Vous devez être connecté pour vous abonnez !");
});